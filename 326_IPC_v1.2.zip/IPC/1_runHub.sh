#!/bin/#!/usr/bin/
g++ -o hub hub.cpp force_patch64.o
./hub
