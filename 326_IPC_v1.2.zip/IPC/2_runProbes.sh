#!/bin/#!/usr/bin/
g++ -o probeManager probeManager.cpp
./probeManager
