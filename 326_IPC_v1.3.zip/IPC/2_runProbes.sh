#!/bin/#!/usr/bin/
g++ -o probeManager probeManager.cpp kill_patch64.o
./probeManager
